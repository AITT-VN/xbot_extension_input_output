# xbot_extension_input_output
Mục mở rộng của xbot cho các module input/output
